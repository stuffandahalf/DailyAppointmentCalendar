Name: Gregory Norton
Class: CPS 209
Student Number: 500766165

Currently selected date is shown in title bar.
Left and right buttons move the date by 1 and refresh the jtextarea with the appointments for that day. date boxes are left with their initial values to easily jump back to current date.
Users can input a specific date and press the show button to jump to that date.
Selecting a time and pressing the create button will try to add an appointment on that day and time with the description set in the textarea assuming that there is not already an appointment there. Pressing cancel will remove the appointment on that day.
selecting "Add Sample Appointments" from the Manage menu will add several appointments to the calendar and a popup will appear to show which dates were added.
Selecting "Clear Appointments" removes all of the appointments from the calendar.

